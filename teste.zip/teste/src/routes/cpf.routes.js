// importa a biblioteca ' express '.
import express from 'express'

// importa o arquivo ' cpf.controller.js '.
import CpfController from '../controller/cpf.controller.js';


// atribui a uma constante a objeto Router da biblioteca express para conseguir usar as funções.
const router = express.Router()

// define uma rota ' /busca ' para fazer requisições GET.
router.get('/busca', CpfController.getCPF);
router.get('/juridico/busca', CpfController.getCPFJuridico)
// exporta a constante router.
export default router


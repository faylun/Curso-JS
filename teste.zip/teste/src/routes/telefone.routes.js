import express from 'express'
import TelefoneController from '../controller/telefone.controller.js';


const router = express.Router()

router.get('/busca', TelefoneController.getTelefone);

router.get('/busca_cnj', TelefoneController.getTelefoneCnj)
export default router
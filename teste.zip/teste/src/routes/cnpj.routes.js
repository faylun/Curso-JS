// importa a biblioteca ' express '.
import express from 'express'

// importa o arquivo ' cnpj.controller.js '.
import CnpjController from '../controller/cnpj.controller.js';

// atribui a uma constante a objeto Router da biblioteca express para conseguir usar as funções.
const router = express.Router()

// define uma rota ' /busca ' para fazer requisições GET.
router.get('/busca', CnpjController.getCnpj);

// exporta a constante router.
export default router
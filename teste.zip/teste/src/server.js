// importando a constante app do arquivo app.js.
import app from './app.js'

// criando número da porta que ficará o localhost.
const PORTA = 3000 

// Colocando o servidor disponível na porta declarada.
app.listen(PORTA, () => {
    console.log('Servidor Escutando!')
})
// importa a biblioteca express para fazer requisição.
import express from 'express'

// importa o arquivo ' telefone.routes.js '.
import telefoneRouter from './routes/telefone.routes.js';

// importa o arquivo ' cpf.routes.js '.
import cpfRouter from './routes/cpf.routes.js'

// importa o arquivo ' cpf.routes.js '.
import cnpjRouter from './routes/cnpj.routes.js'

// Faz a constante app receber um objeto de express para conseguir utilizar as funções.
const app = express()

// transforma o corpo das requisições em JSON.
app.use(express.json())

// cria uma rota padrão que o caminho vai ser ' /credify/telefone '.
app.use('/credify/telefone', telefoneRouter)

// cria uma rota padrão que o caminho vai ser ' /credify/cpf '.
app.use('/credify/cpf', cpfRouter)

// cria uma rota padrão que o caminho vai ser ' /credify/cnpj '.
app.use('/credify/cnpj', cnpjRouter)

// exporta a constante app.
export default app

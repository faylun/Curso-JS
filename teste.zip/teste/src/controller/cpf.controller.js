// importa o arquivo cpfService.
import CpfService from "../services/cpf.service.js";

// importa as funções validaNumeroTelefoneFixo, validaNumeroTelefoneMovel e extrairDigito do arquivo telefoneUtils.js.
import { extrairDigito } from '../utilits/telefone-utils.js'

// Cria uma função assíncrona que recebe um request e uma response.
async function getCPF(req, res){

    // pega o valor passado no parâmetro ' numero '.
    const numeroOriginal = req.query.numero

    // tira caracteres especiais.
    const digitosFormatados = extrairDigito(numeroOriginal) 

    // mostra um log do que foi feito na rota.
    console.log(`INFO: Requisição na rota '/credify/cpf/busca': ${digitosFormatados}.`) 

    try{

        // Verifica se o CPF passado possui 11 digitos.
        if (digitosFormatados.length !== 11){

            throw new Error('ERRO! Informe um CPF válido.')

        }else {

            // mostra um log do que foi feito na rota.
            console.log("INFO: Iniciando a consulta na API externa.")
            
            // manda a resposta do request para a função getCpf.
            res.send(CpfService.getCpf(digitosFormatados));

        }
    }catch (erro){

        // Manda para a função getCpf a mensagem de erro como parâmetro.
        console.log(`ERRO: ${erro.message}`)

    }
}

async function getCPFJuridico(req, res){

    // pega o valor passado no parâmetro ' numero '.
    const numeroOriginal = req.query.numero

    // tira caracteres especiais.
    const digitosFormatados = extrairDigito(numeroOriginal) 

    // mostra um log do que foi feito na rota.
    console.log(`INFO: Requisição na rota '/credify/cpf/juridico/busca': ${digitosFormatados}.`) 

    try{

        // Verifica se o CPF passado possui 11 digitos.
        if (digitosFormatados.length !== 11){

            throw new Error('ERRO! Informe um CPF válido.')

        }else {

            // mostra um log do que foi feito na rota.
            console.log("INFO: Iniciando a consulta na API externa.")
            
            // manda a resposta do request para a função getCpf.
            res.send(CpfService.getCpfJuridico(digitosFormatados));

        }
    }catch (erro){

        // Manda para a função getCpf a mensagem de erro como parâmetro.
        console.log(`ERRO: ${erro.message}`)

    }
}

// exporta a função getCpf.
export default { getCPF, getCPFJuridico }
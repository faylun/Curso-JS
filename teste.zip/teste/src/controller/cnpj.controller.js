// importa o arquivo cnpjService.
import CnpjService from "../services/cnpj.service.js";

// importa as funções validaNumeroTelefoneFixo, validaNumeroTelefoneMovel e extrairDigito do arquivo telefoneUtils.js.
import { extrairDigito } from '../utilits/telefone-utils.js'

// Cria uma função assíncrona que recebe um request e uma response.
async function getCnpj(req, res){

    // pega o valor passado no parâmetro ' numero '.
    const numeroOriginal = req.query.numero

    // tira caracteres especiais.
    const digitosFormatados = extrairDigito(numeroOriginal) 

    // mostra um log do que foi feito na rota.
    console.log(`INFO: Requisição na rota '/credify/cnpj/busca': ${digitosFormatados}.`) 

    try{

        // Verifica se o CNPJ passado possui 14 digitos.
        if (digitosFormatados.length !== 14){

            throw new Error('ERRO! Informe um CNPJ válido.')

        }else {

            // mostra um log do que foi feito na rota.
            console.log("INFO: Iniciando a consulta na API externa.")

            // manda a resposta do request para a função getCnpj.
            res.send(CnpjService.getCnpj(digitosFormatados));

        }
    }catch (erro){

        // Manda para a função getCpf a mensagem de erro como parâmetro.
        console.log(`ERRO ${erro.message}`)

    }
}

// exporta a função getCnpj.
export default { getCnpj }
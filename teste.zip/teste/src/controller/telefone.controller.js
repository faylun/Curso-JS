// importa o arquivo telefoneService.
import TelefoneService from "../services/telefone.service.js";

// importa as funções validaNumeroTelefoneFixo, validaNumeroTelefoneMovel e extrairDigito do arquivo telefoneUtils.js.
import { validaNumeroTelefoneFixo, validaNumeroTelefoneMovel, extrairDigito } from '../utilits/telefone-utils.js'

async function getTelefone(req, res){

     // pega o valor passado no parâmetro ' :numero '.
    const numeroOriginal = req.query.numero;

    // tira os caracteres especiais.
    const numeroFormatado = extrairDigito(numeroOriginal)

    // pega os 8 digitos finais, sem o 55, sem o DDD e sem o 9.
    const numeroTelefone = numeroFormatado.substring(numeroFormatado.length, numeroFormatado.length - 8)

    // mostra um log do que foi feito na rota.
    console.log(`INFO: Requisição na rota '/credify/telefone/busca': ${numeroFormatado}.`)

    try{

        // verifica se o primeiro digito do numero do telefone está entre 2 e 5 (se estiver, ele será Fixo).
        if (parseInt(numeroTelefone[0], 10) >= 2 && parseInt(numeroTelefone[0], 10) <= 5){

            // pega o ddd do número apresentado.
            const ddd = validaNumeroTelefoneFixo(numeroFormatado, numeroTelefone).ddd

            // valida e monta o número fixo com o ddd.
            const numeroFixo = validaNumeroTelefoneFixo(numeroFormatado, numeroTelefone).numeroFixo

            // mostra um log do que foi feito na rota.
            console.log("INFO: Iniciando consulta a API externa pelo número de telefone fixo.")
            
            // Manda para o Telefone Service o resultado do request.
            res.send(TelefoneService.getTelefone(ddd, numeroFixo));

    // verifica se o primeiro digito do numero do telefone está entre 6 e 9 (se estiver, ele será Móvel).
    }else if (parseInt(numeroTelefone[0], 10) >= 6 && parseInt(numeroTelefone[0], 10) <= 9){

        // Valida o número de telefone Móvel e retorna o ddd dele.
        const ddd = validaNumeroTelefoneMovel(numeroFormatado, numeroTelefone).ddd

        // valida o número de telefone Móvel e retorna o número do telefone Móvel montado com o 9 e o ddd.
        const numeroTelefoneComNove = validaNumeroTelefoneMovel(numeroFormatado, numeroTelefone).numeroTelefoneComNove

        // mostra um log do que foi feito na rota.
        console.log("INFO: Iniciando consulta a API externa pelo número de telefone móvel.")

        // Manda para o Telefone Service o resultado do request.
        res.send(TelefoneService.getTelefone(ddd, numeroTelefoneComNove));
        
    // Caso não for nem telefone fixo nem o móvel, ele vai cair no else e mostrar um erro.
    }else {

        // Manda para o Telefone Service o Erro.
        res.send(TelefoneService.getTelefone('ERROR: Formato de número inexistente.'));

    }

// captura os erros que foram causados no try.
    } catch(erro){
        
        // Manda para o Telefone Service o Erro.
        res.send(TelefoneService.getTelefone(`ERRO: ${erro.message}`));

    } 
}

async function getTelefoneCnj(req, res){
    console.log()
    res.send(await TelefoneService.getTelefoneCnj())
}
export default { getTelefone, getTelefoneCnj }
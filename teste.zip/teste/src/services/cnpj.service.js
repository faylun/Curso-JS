// importa o arquivo requisicoesAPI.js.
import { requestAPICPF } from '../services/requisicoesAPI.js'

// define uma função que irá receber uma query como parâmetro e imprimir na tela a mensagem.
async function getCnpj(digitosFormatados){

    // faz o request mandando os digitos sem caracteres especiais.
    const resultado = await requestAPICPF(digitosFormatados)

    console.log(resultado)

}

// exporta a função getCnpj.
export default { getCnpj }
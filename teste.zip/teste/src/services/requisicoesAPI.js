// importa a biblioteca axios para fazer requisições
import axios from 'axios';

// importa a biblioteca xml2js para conseguir transformar o xml em objeto e conseguir manipular.
import xml2js from 'xml2js';

import { xmlParaJsonTelefone, bodyXmlTelefone } from '../utilits/telefone-utils.js'

import { xmlParaJsonCpf, bodyXmlCpf } from '../utilits/cpf-utils.js'

import { bodyXmlCpfJuridico, xmlParaJsonCpfJuridico } from '../utilits/cpf-juridico-utils.js'

import { leituraArquivo, leituraArquivoCpf, leituraArquivoTelefone } from '../utilits/leitura-arquivo.js'

// login da estrutura body do XML.
const logon = '31235'

// senha da estrutura body do XML.
const senha = '78911007'

// ID da Consulta da estrutura body do XML.
let idConsulta = 3

const statusProcesso = 0

const statusPolo = 0

const url = 'http://webservice.credify.com.br/wscredify.php'

/*                            FUNÇÃO REQUEST API CPF                          */


// função assíncrona requestAPICPF passando o número de telefone.
async function requestAPICPF(cpf){

  // Constante com os dados passados no body da requisição a API.
  const dados = bodyXmlCpf(logon, senha, idConsulta, cpf)

    // Dados da requisição que vai ser feita.
    const options = {

    // método POST.
    method: 'POST',

    // URL da API.
    url: url,

    // Parâmetros que serão passados ( Não irá necessitar ).
    params: { '': '' },

    // Headers que serão passados na requisição POST.
    headers: { 'Content-Type': 'text/xml', 'User-Agent': 'insomnia/8.4.5' },

    // O body que será passado ( está na variável ' dados ' ).
    data: dados,

    };

    try {

      // faz a requisição POST a api com os dados exibidos na constante ' options '.
      const response = await axios(options);

      /*
      Transforma os dados da response em String. 
      ( O explicitArray iria transformar a resposta em um array, por isso botamos como false ). 
      ( O explicitRoot iria criar um elemento raiz que encapsularia os outros, por isso botamos como false ).
      */
      const result = await xml2js.parseStringPromise(response.data, { explicitArray: false, explicitRoot: false });

      // pega a response transformada em string e filtra pegando apenas os dados necessários.
      const dados = result['SOAP-ENV:Body']['ns1:ConsultarResponse'].xmlResposta._;
      return xmlParaJsonCpf(leituraArquivoCpf(dados))
      // retorna os dados como objeto.
      return xmlParaJsonCpf(dados)

    // captura os erros do try.
    } catch (error) {

      // transfere os erros para a instrução catch.
      throw error;
  }
}


// função assíncrona requestAPICPF passando o número de telefone.
async function requestAPICPFJuridico(cpf){
  
  idConsulta = 334

  // Constante com os dados passados no body da requisição a API.
  const dados = bodyXmlCpfJuridico(logon, senha, idConsulta, cpf, statusProcesso, statusPolo)

    // Dados da requisição que vai ser feita.
    const options = {

    // método POST.
    method: 'POST',

    // URL da API.
    url: url,

    // Parâmetros que serão passados ( Não irá necessitar ).
    params: { '': '' },

    // Headers que serão passados na requisição POST.
    headers: { 'Content-Type': 'text/xml', 'User-Agent': 'insomnia/8.4.5' },

    // O body que será passado ( está na variável ' dados ' ).
    data: dados,

    };

    try {

      // faz a requisição POST a api com os dados exibidos na constante ' options '.
      const response = await axios(options);

      /*
      Transforma os dados da response em String. 
      ( O explicitArray iria transformar a resposta em um array, por isso botamos como false ). 
      ( O explicitRoot iria criar um elemento raiz que encapsularia os outros, por isso botamos como false ).
      */
      const result = await xml2js.parseStringPromise(response.data, { explicitArray: false, explicitRoot: false });

      // pega a response transformada em string e filtra pegando apenas os dados necessários.
      const dados = result['SOAP-ENV:Body']['ns1:ConsultarResponse'].xmlResposta._;
      
      // retorna os dados como objeto.
      return xmlParaJsonCpfJuridico(leituraArquivo())

    // captura os erros do try.
    } catch (error) {

      // transfere os erros para a instrução catch.
      throw error;
  }
}


/*                          FUNÇÃO REQUEST API TELEFONE                       */


// função assíncrona requestApiTelefone passando o ddd e o número de telefone.
async function requestApiTelefone(ddd, numero){

  // muda o valor do ID da consulta para 7.
  idConsulta = 7

  // Constante com os dados passados no body da requisição a API.
  const dados = bodyXmlTelefone(logon, senha, idConsulta, ddd, numero)

  // Dados da requisição que vai ser feita.
  const options = {

    // método POST.
    method: 'POST',

    // URL da API.
    url: url,

    // Parâmetros que serão passados ( Não irá necessitar ).
    params: { '': '' },

    // Headers que serão passados na requisição POST.
    headers: { 'Content-Type': 'text/xml', 'User-Agent': 'insomnia/8.4.5' },

    // O body que será passado ( está na variável ' dados ' ).
    data: dados,
  }

  try {

    // faz a requisição POST a api com os dados exibidos na constante ' options '.
    const response = await axios(options);

    /*
    Transforma os dados da response em String. 
    ( O explicitArray iria transformar a resposta em um array, por isso botamos como false ). 
    ( O explicitRoot iria criar um elemento raiz que encapsularia os outros, por isso botamos como false ).
    */
    const result = await xml2js.parseStringPromise(response.data, { explicitArray: false, explicitRoot: false })

    // pega a response transformada em string e filtra pegando apenas os dados necessários.
    const dados = result['SOAP-ENV:Body']['ns1:ConsultarResponse'].xmlResposta._

    // retorna os dados filtrados como objeto.
    return xmlParaJsonTelefone(leituraArquivoTelefone())

    // captura os erros do try.
  } catch (error) {

    // transfere os erros para a instrução catch.
    throw error;
  }
}

// exporta a função requestAPICPF e requestApiTelefone.
export { requestAPICPF, requestApiTelefone, requestAPICPFJuridico } 
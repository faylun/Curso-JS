// importa as funções requestAPICPF e requestApiTelefone do arquivo requisicoesAPI.js.
import { requestApiTelefone } from '../services/requisicoesAPI.js'
import { escritaArquivoTelefone } from '../utilits/leitura-arquivo.js'

async function getTelefone(ddd, telefone){

    // tratar excessões da api.
    const resultado = await requestApiTelefone(ddd, telefone)
    
    escritaArquivoTelefone(resultado)
    console.log(resultado)

}

export default { getTelefone }
// importa o arquivo requisicoesAPI.js.
import { requestAPICPF, requestAPICPFJuridico } from '../services/requisicoesAPI.js'
import { escritaArquivoJuridico, escritaArquivoCpf } from '../utilits/leitura-arquivo.js'

// define uma função que irá receber uma query como parâmetro e imprimir na tela a mensagem.
async function getCpf(digitosFormatados){

    // faz o request mandando os digitos sem caracteres especiais.
    const resultado = await requestAPICPF(digitosFormatados)

    escritaArquivoCpf(resultado)
    console.log(resultado)

}

async function getCpfJuridico(digitosFormatados){

    // faz o request mandando os digitos sem caracteres especiais.
    const resultado = await requestAPICPFJuridico(digitosFormatados)

    escritaArquivoJuridico(resultado)
    console.log(resultado)

}

// exporta a função getCpf.
export default { getCpf, getCpfJuridico }
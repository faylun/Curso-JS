export function xmlParaJsonCpfJuridico(dados){
  const regexTags = /<([^>]+)>(.*?)<(\/\1)>/g
  const regexRegistro =  /<REGISTRO(\d+)>(.*?)<\/REGISTRO(\d+)>/g

  let matchRespostaTags
  let matchRegistro

  const respostaTags = {}
  const dadosTags = {}
  const buscaConsulta = {}
  const tagResposta = {}
  const dadosCadastrais = {}
  const data = {}
  const classeProcessual = {}
  const statusPredictus = {}
  const julgamentos = {}
  const registroParte = {}

  while((matchRespostaTags = regexTags.exec(dados)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    respostaTags[tagNome] = tagValor
  }

  while((matchRespostaTags = regexTags.exec(respostaTags.XML)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    dadosTags[tagNome] = tagValor
  }

  respostaTags.XML = dadosTags

  while((matchRespostaTags = regexTags.exec(dadosTags.CONSULTA)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    buscaConsulta[tagNome] = tagValor
  }

  dadosTags.CONSULTA = buscaConsulta

  while((matchRespostaTags = regexTags.exec(dadosTags.RESPOSTA)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    tagResposta[tagNome] = tagValor
  }

  dadosTags.RESPOSTA = tagResposta

  while((matchRespostaTags = regexTags.exec(dadosTags.RESPOSTA.DADOSCADASTRAIS)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    dadosCadastrais[tagNome] = tagValor
  }

  dadosTags.RESPOSTA.DADOSCADASTRAIS = dadosCadastrais

  while((matchRespostaTags = regexTags.exec(dadosTags.RESPOSTA.DATA)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    data[tagNome] = tagValor
  }

  dadosTags.RESPOSTA.DATA = data

  while((matchRespostaTags = regexTags.exec(dadosTags.RESPOSTA.DATA.CLASSEPROCESSUAL)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    classeProcessual[tagNome] = tagValor
  }

  dadosTags.RESPOSTA.DATA.CLASSEPROCESSUAL = classeProcessual

  while((matchRespostaTags = regexTags.exec(dadosTags.RESPOSTA.DATA.STATUSPREDICTUS)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    statusPredictus[tagNome] = tagValor
  }

  dadosTags.RESPOSTA.DATA.STATUSPREDICTUS = statusPredictus

  while((matchRespostaTags = regexTags.exec(statusPredictus.JULGAMENTOS)) !== null){
    const tagNome = matchRespostaTags[1]
    const tagValor = matchRespostaTags[2]
    julgamentos[tagNome] = tagValor
  }
  
  dadosTags.RESPOSTA.DATA.STATUSPREDICTUS.JULGAMENTOS = julgamentos

  while((matchRegistro = regexTags.exec(dadosTags.RESPOSTA.DATA.PARTES)) !== null){
    const tagNome = matchRegistro[1]
    const tagValor = matchRegistro[2]
    registroParte[tagNome] = tagValor
  }

  while((matchRegistro = regexRegistro.exec(dadosTags.RESPOSTA.DATA.PARTES)) !== null){
    const registroPartes = {}
    while((matchRespostaTags = regexTags.exec(registroParte[`REGISTRO${matchRegistro[1]}`])) !== null){
      const tagNome = matchRespostaTags[1]
      const tagValor = matchRespostaTags[2]
      registroPartes[tagNome] = tagValor
    }
    registroParte[`REGISTRO${matchRegistro[1]}`] = registroPartes
  }

  dadosTags.RESPOSTA.DATA.PARTES = registroParte

  return dadosTags
}


export function bodyXmlCpfJuridico(logon, senha, idConsulta, cpf, statusProcesso, statusPolo){
    return `
    <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
    xmlns:urn="urn:server.consultas">
    <soapenv:Header/>
        <soapenv:Body>
          <urn:Consultar soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
            <xmlRequisicao xsi:type="xsd:string">
                      <![CDATA[<xml>
                        <ACESSO>
                            <LOGON>${logon}</LOGON>
                            <SENHA>${senha}</SENHA>
                        </ACESSO>
                        <CONSULTA>
                            <IDCONSULTA>${idConsulta}</IDCONSULTA>
                            <CPFCNPJ>${cpf}</CPFCNPJ>
                            <TIPOPESSOA>F</TIPOPESSOA>

                            <FILTROS>
                                <STATUSPROCESSO>${statusProcesso}</STATUSPROCESSO>
                                <STATUSPOLO>${statusPolo}</STATUSPOLO>
                            </FILTROS>
                          </CONSULTA>
                      </xml>]]>
              </xmlRequisicao>
          </urn:Consultar>
        </soapenv:Body>
  </soapenv:Envelope>`
}
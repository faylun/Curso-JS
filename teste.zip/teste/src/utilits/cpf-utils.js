export function xmlParaJsonCpf(dados){

  const regexTags = /<([^>]+)>(.*?)<\/\1>/g
  const regexRegistro =  /<REGISTRO_(\d+)>(.*?)<\/REGISTRO_(\d+)>/g

  let matchResposta
  let matchDados
  let matchDadosCadastrais
  let matchMoradoresEnderecos
  let matchRegistros
  let matchRegistrosDados
  let matchEndereco

  const respostaTags = {}
  const dadosTags = {}
  const dadosCadastrais = {}
  const moradoresEnderecos = {}
  const enderecosRegistro = {}
  const telefonesRegistro = {}
  const participacaoSocietaria = {}

  while ((matchResposta = regexTags.exec(dados)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    respostaTags[nomeResposta] = valorResposta
  }

  dados = respostaTags

  while ((matchResposta = regexTags.exec(dados.CONSULTA)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    dadosTags[nomeResposta] = valorResposta
  }
  dados.CONSULTA = dadosTags

  while ((matchResposta = regexTags.exec(dados.DADOSCADASTRAIS)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    dadosCadastrais[nomeResposta] = valorResposta
  }

  dados.DADOSCADASTRAIS = dadosCadastrais

  while ((matchResposta = regexTags.exec(dados.DADOSCADASTRAIS)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    dadosCadastrais[nomeResposta] = valorResposta
  }

  while ((matchResposta = regexTags.exec(dados.MORADORESENDERECO)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    moradoresEnderecos[nomeResposta] = valorResposta
  }

  while((matchRegistros = regexRegistro.exec(dados.MORADORESENDERECO)) !== null){
    const registroMoradoresEnderecos = {}
    while ((matchRegistrosDados = regexTags.exec(moradoresEnderecos[`REGISTRO_${matchRegistros[1]}`])) !== null){
        const moradoresEnderecosName = matchRegistrosDados[1]
        const moradoresEnderecosValor = matchRegistrosDados[2]
        registroMoradoresEnderecos[moradoresEnderecosName] = moradoresEnderecosValor
    }
    
    moradoresEnderecos[`REGISTRO_${matchRegistros[1]}`] = registroMoradoresEnderecos
  }

  dados.MORADORESENDERECO = moradoresEnderecos

  while((matchRegistros = regexTags.exec(dados.ENDERECOS)) !== null){
    const enderecosRegistroName = matchRegistros[1]
    const enderecosRegistroValor = matchRegistros[2]
    enderecosRegistro[enderecosRegistroName] = enderecosRegistroValor
}

  while ((matchRegistros = regexRegistro.exec(dados.ENDERECOS)) !== null){
    const registroEndereco = {}

    while((matchEndereco = regexTags.exec(enderecosRegistro[`REGISTRO_${matchRegistros[1]}`])) !== null){
      const tipoEnderecosName = matchEndereco[1]
      const tipoEnderecosValor = matchEndereco[2]
      registroEndereco[tipoEnderecosName] = tipoEnderecosValor
    }

    enderecosRegistro[`REGISTRO_${matchRegistros[1]}`] = registroEndereco
  }

  dados.ENDERECOS = enderecosRegistro

  while((matchRegistros = regexTags.exec(dados.TELEFONES)) !== null){
    const telefoneName = matchRegistros[1]
    const telefoneValor = matchRegistros[2]
    telefonesRegistro[telefoneName] = telefoneValor
  }

  while ((matchRegistros = regexRegistro.exec(dados.TELEFONES)) !== null){
    const registroTelefone = {}

    while((matchEndereco = regexTags.exec(telefonesRegistro[`REGISTRO_${matchRegistros[1]}`])) !== null){
      const tipoTelefoneName = matchEndereco[1]
      const tipoTelefoneValor = matchEndereco[2]
      registroTelefone[tipoTelefoneName] = tipoTelefoneValor
    }

    telefonesRegistro[`REGISTRO_${matchRegistros[1]}`] = registroTelefone
  }

  dados.TELEFONES = telefonesRegistro
  
  while((matchRegistros = regexTags.exec(dados.PARTICIPACAOSOCIETARIA)) !== null){
    const participacaoSocietariaNome = matchRegistros[1]
    const participacaoSocietariaValor = matchRegistros[2]
    participacaoSocietaria[participacaoSocietariaNome] = participacaoSocietariaValor
  }

  while ((matchRegistros = regexRegistro.exec(dados.PARTICIPACAOSOCIETARIA)) !== null){
    const registroSocietario = {}

    while((matchEndereco = regexTags.exec(participacaoSocietaria[`REGISTRO_${matchRegistros[1]}`])) !== null){
      const participacaoSocietariaNome = matchEndereco[1]
      const participacaoSocietariaValor = matchEndereco[2]
      registroSocietario[participacaoSocietariaNome] = participacaoSocietariaValor
    }

    participacaoSocietaria[`REGISTRO_${matchRegistros[1]}`] = registroSocietario
  }
  dados.PARTICIPACAOSOCIETARIA = participacaoSocietaria
  return dados
  /*
  while ((matchResposta = regexTags.exec(dados)) !== null){
    const nomeResposta = matchResposta[1]
    const valorResposta = matchResposta[2]
    respostaTags[nomeResposta] = valorResposta
  }

  while ((matchDados = regexTags.exec(respostaTags.RESPOSTA)) !== null){
    const nomeDados = matchDados[1]
    const valorDados = matchDados[2]
    dadosTags[nomeDados] = valorDados
  }

  while ((matchDadosCadastrais = regexTags.exec(dadosTags.DADOSCADASTRAIS)) !== null){
    const dadosName = matchDadosCadastrais[1]
    const dadosValor = matchDadosCadastrais[2]
    dadosCadastrais[dadosName] = dadosValor
  }

  dadosTags.DADOSCADASTRAIS = dadosCadastrais

  while ((matchMoradoresEnderecos = regexTags.exec(dadosTags.MORADORESENDERECO)) !== null){
    const moradoresEnderecosName = matchMoradoresEnderecos[1]
    const moradoresEnderecosValor = matchMoradoresEnderecos[2]
    moradoresEnderecos[moradoresEnderecosName] = moradoresEnderecosValor
  }

  while((matchRegistros = regexRegistro.exec(dadosTags.MORADORESENDERECO)) !== null){
    const registroMoradoresEnderecos = {}
    while ((matchRegistrosDados = regexTags.exec(moradoresEnderecos[`REGISTRO_${matchRegistros[1]}`])) !== null){
        const moradoresEnderecosName = matchRegistrosDados[1]
        const moradoresEnderecosValor = matchRegistrosDados[2]
        registroMoradoresEnderecos[moradoresEnderecosName] = moradoresEnderecosValor
    }
    
    moradoresEnderecos[`REGISTRO_${matchRegistros[1]}`] = registroMoradoresEnderecos
  }

  dadosTags.MORADORESENDERECO = moradoresEnderecos

  while((matchRegistros = regexTags.exec(dadosTags.ENDERECOS)) !== null){
        const enderecosRegistroName = matchRegistros[1]
        const enderecosRegistroValor = matchRegistros[2]
        enderecosRegistro[enderecosRegistroName] = enderecosRegistroValor
  }

  while ((matchRegistros = regexRegistro.exec(dadosTags.ENDERECOS)) !== null){
    const registroEndereco = {}

    while((matchEndereco = regexTags.exec(enderecosRegistro[`REGISTRO_${matchRegistros[1]}`])) !== null){
      const tipoEnderecosName = matchEndereco[1]
      const tipoEnderecosValor = matchEndereco[2]
      registroEndereco[tipoEnderecosName] = tipoEnderecosValor
    }

    enderecosRegistro[`REGISTRO_${matchRegistros[1]}`] = registroEndereco
  }

  dadosTags.ENDERECOS = enderecosRegistro
    
  while((matchRegistros = regexTags.exec(dadosTags.TELEFONES)) !== null){
    const telefoneName = matchRegistros[1]
    const telefoneValor = matchRegistros[2]
    telefonesRegistro[telefoneName] = telefoneValor
  }

  while ((matchRegistros = regexRegistro.exec(dadosTags.TELEFONES)) !== null){
    const registroTelefone = {}

    while((matchEndereco = regexTags.exec(telefonesRegistro[`REGISTRO_${matchRegistros[1]}`])) !== null){
      const tipoTelefoneName = matchEndereco[1]
      const tipoTelefoneValor = matchEndereco[2]
      registroTelefone[tipoTelefoneName] = tipoTelefoneValor
    }

    telefonesRegistro[`REGISTRO_${matchRegistros[1]}`] = registroTelefone
  }

  dadosTags.TELEFONES = telefonesRegistro

  return dadosTags
  */
}


  export function bodyXmlCpf(logon, senha, idConsulta, cpf){
    return `
  <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
  xmlns:urn="urn:server.consultas">
  <soapenv:Header/>
      <soapenv:Body>
        <urn:Consultar soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <xmlRequisicao xsi:type="xsd:string">
                    <![CDATA[<xml>
                        <ACESSO>
                        <LOGON>${logon}</LOGON>
                        <SENHA>${senha}</SENHA>
                        </ACESSO>
                        <CONSULTA>
                        <IDCONSULTA>${idConsulta}</IDCONSULTA>
                        <CPFCNPJ>${cpf}</CPFCNPJ>
                        <TIPOPESSOA>F</TIPOPESSOA>
                        </CONSULTA>
                    </xml>]]>
            </xmlRequisicao>
        </urn:Consultar>
      </soapenv:Body>
</soapenv:Envelope>`
                    }


  /*                                 FUNÇÃO GET CPF                             */


  // função para pegar o CPF na response da requisição XML.
  function getCPF() {

    // faz a requisição POST a api com os dados exibidos na constante ' options '.
    axios.request(options)
  
         // usa o then para utilizar a requisição de forma assíncrona.
         .then((response) => { 
  
        /*
          Transforma os dados da response em String. 
          ( O explicitArray iria transformar a resposta em um array, por isso botamos como false ). 
          ( O explicitRoot iria criar um elemento raiz que encapsularia os outros, por isso botamos como false ).
        */
        xml2js.parseString(response.data, { explicitArray: false, explicitRoot: false }, ((err, result) => {
  
          // Filtra a response do XML e pega o CPF.
          const cpf = result['SOAP-ENV:Body']['ns1:ConsultarResponse'].xmlResposta._
  
          // Regex para pegar somente os digitos onde possui as tags ' <CPF> ' .
          const regex = /<CPF>(\d+)/
  
          // converte a coleção MatchAll ( utilizado para encontrar todas as correspondências na string cpf ) em um array.
          const captura = [...cpf.matchAll(regex)]
  
          /* 
            itera sobre o array utilizando o map. A função callback retorna o valor correspondente ao índice 1 do objeto
            iteravel 
          */
          const resultado = captura.map(capture => {
            console.log(capture[1]);
          })
  
          // retorna o resultado concatenado com o join().
          return resultado.join()
        }))
  
        // pega os erros do try.
      }).catch((error) => console.error(error))
  }  
import fs from 'fs'

const pathFile = '/home/kauan.silveira/Downloads/Clientes/Credify/resposta-xml-juridica-cpf.txt'
const pathFileCpf = '/home/kauan.silveira/Downloads/Clientes/Credify/resposta-xml-cpf.txt'
const pathFiletelefone = '/home/kauan.silveira/Downloads/Clientes/Credify/resposta-xml-telefone.txt'

export function leituraArquivo(){
    try{
        return fs.readFileSync(pathFile, 'utf-8')
    } catch (erro) {
        console.log(erro)
        return null
    }
}

export function leituraArquivoCpf(){
    try{
        return fs.readFileSync(pathFileCpf, 'utf-8')
    } catch (erro) {
        console.log(erro)
        return null
    }
}

export function leituraArquivoTelefone(){
    try{
        return fs.readFileSync(pathFiletelefone, 'utf-8')
    } catch (erro) {
        console.log(erro)
        return null
    }
}

export function escritaArquivoJuridico(dados){
    const dadosString = JSON.stringify(dados, null, 2)
    fs.appendFile('dados-juridicos.txt', dadosString + '\n\n', (error) => {
        if (error){
            console.log('Erro ao escrever no arquivo.', error)
            return
        }
        console.log('Dados gravados com sucesso!')
    })
}

export function escritaArquivoCpf(dados){
    const dadosString = JSON.stringify(dados, null, 2)
    fs.appendFile('dados-cpf.txt', dadosString + '\n\n', (error) => {
        if (error){
            console.log('Erro ao escrever no arquivo.', error)
            return
        }
        console.log('Dados gravados com sucesso!')
    })
}

export function escritaArquivoTelefone(dados){
    const dadosString = JSON.stringify(dados, null, 2)
    fs.appendFile('dados-telefone.txt', dadosString + '\n\n', (error) => {
        if (error){
            console.log('Erro ao escrever no arquivo.', error)
            return
        }
        console.log('Dados gravados com sucesso!')
    })
}
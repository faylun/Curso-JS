// lista com todos os DDDs válidos.
const dddValidos = [61, 62, 64, 65, 66 ,67, 82, 71, 73, 74, 75, 77, 85, 88, 98, 99, 83, 81, 87, 86, 89, 84, 79,
68, 96, 92, 97, 91, 93, 94, 69, 95, 63, 27, 28, 31, 32, 33, 34, 35, 37, 38, 21, 22, 24, 11, 12, 13, 14, 15, 16,
17, 18, 19, 41, 42, 43, 44, 45, 46, 51, 52, 53, 54, 55, 47, 48, 49]



// Cria e exporta a função extrairDigito e passa como parâmetro o número digitado.
export function extrairDigito(digito){
    // regex criado para buscar todos os digitos na palavra ( sem caracteres especiais ).
    const regex = /\d/g;

    // utiliza o metódo match para encontrar correspondências de acordo com o regex.
    const numeroArray = digito.match(regex)

    /* 
       if ternário onde se o numeroArray for verdadeiro, irá retornar o número sem espaços e sem caracteres especiais.
       Caso contrário, irá retornar ' N/I '.
    */
    return numeroArray ? numeroArray.join('') : 'N/I';
}

// Cria a função extrairDDD e passa como parâmetro o número Formatado.
function extrairDDD(numeroFormatado){

    // cria a variável ddd.
    let ddd

   // Verifica se o número Formatado é igual a 10, 11 ou 12.
    if (numeroFormatado.length == 10 || numeroFormatado.length == 11 || numeroFormatado.length == 12){

        //verifica se o primeiro digito é 0, se for, ele atribui ao ddd os digitos 2 e 3, se não, ele atribui o 1° e o 2°.
        numeroFormatado[0] == '0' ? ddd = numeroFormatado.substring(1, 3) : ddd = numeroFormatado.substring(0, 2)

    } 

    // Verifica se o número formatado é igual a 13 ou 14.
    if (numeroFormatado.length == 13 || numeroFormatado.length == 14){

         // verifica se o número Formatado começa com 55.
        if (numeroFormatado.substring(0, 2) == '55'){
            
            // se começar com 55, o ddd serpá os 2 próximos números após o 55.
            ddd = numeroFormatado.substring(2, 5)

            // if ternário onde verifica se o primeiro elemento do ddd é 0. Se for, o 0 é retirado. 
            // Se não for, continua como está.
            ddd[0] === '0' ? ddd = numeroFormatado.substring(3, 5) : ddd = numeroFormatado.substring(2, 4)

        // Caso não comece com 55 vai cair no else.
        } else {

            // o ddd começa recendo os 2 primeiros digitos do número Formatado.
            ddd = numeroFormatado.substring(0, 2)

            // se o primeiro caracter do ddd for igual a 0, ele irá retirar ele. Caso contrário, irá deixar como está.
            if (ddd[0] === '0') ddd = numeroFormatado.substring(1, 3)

        }
    }

    // retorna o DDD.
    return ddd
}

// Cria e exporta a função validaNumeroTelefoneFixo e passa como parâmetro o número Formatado e o numero de Telefone.
export function validaNumeroTelefoneFixo(numeroFormatado, numeroTelefone){

    // cria uma variável ddd e atribui o retorno da função extrairDDD a ela.
    let ddd = extrairDDD(numeroFormatado)

        // Se o DDD não estiver na lista de DDDs válidos, irá acontecer um Erro já tratado.
        if (!dddValidos.toString().includes(ddd)){
            throw new Error('DDD inválido.')
        }

        // Cria o número fixo passando o ddd e o número de telefone.
        const numeroFixo = numeroTelefone

        // Se o tamanho do número Fixo criado for diferente de 10 caracteres, ele irá retornar um erro já tratado.
        if (numeroFixo.length !== 8){
            throw new Error('ERRO! O número de caracteres não correspondem a um telefone fixo válido.')
        }

        // retorna o ddd e o número fixo.
        return {ddd: ddd, numeroFixo: numeroFixo}
}

// Cria e exporta a função validaNumeroTelefoneMovel passando como parâmetro o número Formatado e o número de telefone.
export function validaNumeroTelefoneMovel(numeroFormatado, numeroTelefone){

    // cria a variável ddd e atribui a ela o retorno da função extrairDDD.
    let ddd = extrairDDD(numeroFormatado)
    
    // Se o DDD não estiver na lista de DDDs válidos, irá acontecer um Erro já tratado.
    if (!dddValidos.toString().includes(ddd)){
        throw new Error('DDD inválido.')
    }

    // Cria o número móvel passando o ddd, o 9 e o número de telefone.
    const numeroTelefoneComNove = "9" + numeroTelefone

    // Se o tamanho número de Telefone com 9 for diferente de 14 e 11, ele irá dar um erro já tratado.
    if (numeroTelefoneComNove.length !== 9 && numeroTelefoneComNove.length !== 11){
        throw new Error('ERRO! O número de caracteres não correspondem a um telefone válido.')
    }

    // retorna o ddd e o número de telefone com 9.
    return {ddd: ddd, numeroTelefoneComNove: numeroTelefoneComNove}
}

export function xmlParaJsonTelefone(dados){

    
    const regexTags = /<([^>]+)>(.*?)<\/\1>/g
    const regexRegistro =  /<REGISTRO_(\d+)>(.*?)<\/REGISTRO_(\d+)>/g

    let matchRespostaTags
    let matchRegistro

    const respostaTags = {}
    const dadosTags = {}
    const consulta = {}
    const resposta = {}
    const buscaTelefone = {}

    while((matchRespostaTags = regexTags.exec(dados)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        respostaTags[tagNome] = tagValor
    }

    dados = respostaTags

    while((matchRespostaTags = regexTags.exec(dados.XML)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        dadosTags[tagNome] = tagValor
    }

    dados.XML = dadosTags

    while((matchRespostaTags = regexTags.exec(dados.XML.CONSULTA)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        consulta[tagNome] = tagValor
    }

    dados.XML.CONSULTA = consulta
        
    while((matchRespostaTags = regexTags.exec(dados.XML.RESPOSTA)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        resposta[tagNome] = tagValor
    }

    dados.XML.RESPOSTA = resposta

    while((matchRespostaTags = regexTags.exec(dados.XML.RESPOSTA.BUSCATELEFONE)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        buscaTelefone[tagNome] = tagValor
    }

    while((matchRespostaTags = regexRegistro.exec(dados.XML.RESPOSTA.BUSCATELEFONE)) !== null){
        const registroRespostaTelefone = {}

        while ((matchRegistro = regexTags.exec(buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`])) !== null){
            const respostaRegistroNome = matchRegistro[1]
            const respostaRegistroValor = matchRegistro[2]
            registroRespostaTelefone[respostaRegistroNome] = respostaRegistroValor
        }

        buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`] = registroRespostaTelefone
    }

    dados.XML.RESPOSTA.BUSCATELEFONE = buscaTelefone
    
    return dados
    /*
    while((matchRespostaTags = regexTags.exec(dados)) !== null){
        const tagNome = matchRespostaTags[1]
        const tagValor = matchRespostaTags[2]
        respostaTags[tagNome] = tagValor
    }
    
    while((matchRespostaTags = regexTags.exec(respostaTags.RESPOSTA)) !== null){
        const respostaNome = matchRespostaTags[1]
        const respostaValor = matchRespostaTags[2]
        dadosTags[respostaNome] = respostaValor
    }

    while ((matchRespostaTags = regexTags.exec(dadosTags.BUSCATELEFONE)) !== null){
        const buscaTelefoneName = matchRespostaTags[1]
        const buscaTelefoneValor = matchRespostaTags[2]
        buscaTelefone[buscaTelefoneName] = buscaTelefoneValor
    }

    while((matchRespostaTags = regexRegistro.exec(buscaTelefone)) !== null){
        const registroResposta = {}

        while ((matchRegistro = regexTags.exec(buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`])) !== null){
            const respostaRegistroNome = matchRegistro[1]
            const respostaRegistroValor = matchRegistro[2]
            registroResposta[respostaRegistroNome] = respostaRegistroValor
        }

        buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`] = registroResposta
    }

    while((matchRespostaTags = regexRegistro.exec(dadosTags.BUSCATELEFONE)) !== null){
        const respostaRespostaBusca = {}

        while((matchRegistro = regexTags.exec(buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`])) !== null){
            const respostaDadosNome = matchRegistro[1]
            const respostaDadosValor = matchRegistro[2]
            respostaRespostaBusca[respostaDadosNome] = respostaDadosValor
        }

        buscaTelefone[`REGISTRO_${matchRespostaTags[1]}`] = respostaRespostaBusca
    }

    dadosTags.BUSCATELEFONE = buscaTelefone

    return dadosTags
    */
}


export function bodyXmlTelefone(logon, senha, idConsulta, ddd, numero){
    return `
  <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
  xmlns:urn="urn:server.consultas">
  <soapenv:Header/>
      <soapenv:Body>
        <urn:Consultar soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <xmlRequisicao xsi:type="xsd:string">
                    <![CDATA[<xml>
                        <ACESSO>
                        <LOGON>${logon}</LOGON>
                        <SENHA>${senha}</SENHA>
                        </ACESSO>
                        <CONSULTA>
                        <IDCONSULTA>${idConsulta}</IDCONSULTA>
                        <DDD>${ddd}</DDD>
                        <TELEFONE>${numero}</TELEFONE>
                        <TIPOPESSOA>F</TIPOPESSOA>
                        </CONSULTA>
                    </xml>]]>
            </xmlRequisicao>
        </urn:Consultar>
      </soapenv:Body>
</soapenv:Envelope>`
}